<?php
include_once('connection.php');
include('connection.php');

$stu_app_class = $_POST['stu_app_class'];
$stu_group = $_POST['stu_group'];
$stu_name = $_POST['stu_name'];
$stu_name_op = $_POST['stu_name_op'];
$imgInp = "images";
$stu_f_name = $_POST['stu_f_name'];
$father_nid_number = $_POST['father_nid_number'];
$stu_m_name = $_POST['stu_m_name'];
$mother_nid_number = $_POST['mother_nid_number'];
$stu_dob = $_POST['stu_dob'];
$stu_birth_certificate = $_POST['stu_birth_certificate'];
$stu_nationality = $_POST['stu_nationality'];
$stu_blood_group = $_POST['stu_blood_group'];
$stu_email = $_POST['stu_email'];
$stu_gender = $_POST['stu_gender'];
$stu_religion = $_POST['stu_religion'];
$stu_marital_status = $_POST['stu_marital_status'];
$stu_present_address1 = $_POST['stu_present_address1'];
$stu_present_address2 = $_POST['stu_present_address2'];
$stu_present_address3 = $_POST['stu_present_address3'];
$stu_present_address4 = $_POST['stu_present_address4'];
$stu_permanent_address1 = $_POST['stu_permanent_address1'];
$stu_permanent_address2 = $_POST['stu_permanent_address2'];
$stu_permanent_address3 = $_POST['stu_permanent_address3'];
$stu_permanent_address4 = $_POST['stu_permanent_address4'];


$target = "images/" . basename($_FILES['user_avatar']['name']);
$user_avatar = $_FILES['user_avatar']['name'];

if (move_uploaded_file($_FILES['user_avatar']['tmp_name'], $target)) {
    $msg = "Image upload";
} else {
    $msg = "Image not upload";
}


$sql = "INSERT INTO students (stu_app_class, stu_group, stu_name, stu_name_op, imgInp, stu_f_name, father_nid_number, stu_m_name, mother_nid_number, stu_dob, stu_birth_certificate, stu_nationality, stu_blood_group, stu_email, stu_gender, stu_religion, stu_marital_status, stu_present_address1, stu_present_address2, stu_present_address3, stu_present_address4, stu_permanent_address1, stu_permanent_address2, stu_permanent_address3, stu_permanent_address4) VALUES ('$stu_app_class', '$stu_group', '$stu_name', '$stu_name_op', '$user_avatar', '$stu_f_name', '$father_nid_number', '$stu_m_name', '$mother_nid_number', '$stu_dob', '$stu_birth_certificate', '$stu_nationality', '$stu_blood_group', '$stu_email', '$stu_gender', '$stu_religion', '$stu_marital_status', '$stu_present_address1', '$stu_present_address2', '$stu_present_address3', '$stu_present_address4', '$stu_permanent_address1', '$stu_permanent_address2', '$stu_permanent_address3', '$stu_permanent_address4')";

 
if ($conn->query($sql)) {
    echo '<script>alert("successfully done registration")</script>';
} else {
    echo '<script>alert("no execute")</script>';
}

header('location: apply-online.php');
