<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/images/schoolLogo.jpg">

    <title> Shere-e-bangla High School </title>

    <link rel="stylesheet" href="assets/css/goolips.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/vendors/marquee/marquee.css">
    <link rel="stylesheet" href="assets/css/protip.min.css">
    <link rel="stylesheet" href="assets/index.css">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/color/color10.css">
    <link rel="stylesheet" href="assets/css/color/color-unset.css">
    <link href="assets/vendors/lightgallery/css/lightgallery.css" rel="stylesheet">

    <script src="assets/js/jquery-3.4.1.js"></script>
    <script src="assets/vendors/marquee/marquee.js"></script>
</head>

<body>
    <div id="header"></div>

    <link href="assets/vendors/select2/select2.min.css" rel="stylesheet" />

    <style>
        .select2-container--default .select2-search--dropdown .select2-search__field {
            border: 1px solid #aaa;
            outline: 0;
        }

        .select2-container {
            width: 100% !important;
        }

        input {
            text-transform: uppercase;
        }

        .card-overlay {
            position: absolute;
            background: #c1c1c129;
            width: 100%;
            height: 100%;
            bottom: 0;
            left: 0;
            z-index: 9;
        }

        .modal-backdrop {
            z-index: -1;
            position: unset;
        }

        .modal {
            background-color: rgba(0, 0, 0, 0.5);
        }

        .alert-warning p {
            color: unset;
        }

        @media(max-width: 767px) {
            .apply-form .control-label {
                margin-top: 10px;
                font-size: 13px;
            }
        }
    </style>

    <link href="assets/vendors/datepicker/dist/the-datepicker.css" rel="stylesheet" />

    <link rel="stylesheet" href="../code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="../code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="assets/vendors/select2/select2.min.js"></script>
    <link rel="stylesheet" href="assets/css/apply.css">



    <section class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>অনলাইন ভর্তি</h2>
                    <ul class="bread-list">
                        <li><a href="index.html">হোম<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a>অনলাইন ভর্তি</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <form method="post" action="add.php" id="selectFrom" class="form-horizontal" role="form" enctype="multipart/form-data" accept-charset="utf-8">
        <input type="hidden" name="eiin_number" value="129421">
        <section class="apply-form py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div align="center">
                        </div>

                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="card-title mb-0"> ভর্তি সংক্রান্ত তথ্য </h5>
                            </div>
                            <div class="card-body">
                                <div class="row justify-content-center">
                                    <div class="col-md-3 col-md-offset-3 col-6">
                                        <label class="control-label"> ভর্তিচ্ছু শ্রেণি <code>*</code> </label>
                                        <select name='stu_app_class' class='form-control my_classID select2' required>
                                            <option value='none'>Select One </option>
                                            <option value='Five'>Five</option>
                                            <option value='Six'>Six</option>
                                            <option value='Seven'>Seven</option>
                                            <option value='Eight'>Eight</option>
                                            <option value='Nine'>Nine</option>
                                        </select>
                                    </div>

                                    <div class="col-md-3 col-6">
                                        <label class="control-label"> ভর্তিচ্ছু বিভাগ </label>
                                        <select name='stu_group' class='form-control select2'>
                                            <option value='none'>Select One </option>
                                            <option value='Humanities'>Humanities</option>
                                            <option value='Science'>Science</option>
                                            <option value='Business Studies'>Business Studies</option>
                                        </select>
                                    </div>
                                    <div class="separator10" style='float:left; margin: 10px 0 0 0; width: 100%;'></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container hide_me">
                <div class="row">

                    <div class="col-12">
                        <div id="remarks" class="alert alert-warning" style="margin-bottom: 15px; padding: 15px; border-radius: 5px;"></div>
                    </div>

                    <div class="col-md-12">
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="card-title mb-0"> ব্যক্তিগত তথ্য </h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="separator10"></div>
                                        <div class="row">
                                            <div class="col-12 mb-3 text-center">
                                                <img id="blah" src="images/student.jpg" width="100px" height="100px" style=" margin-top: 15px;border-radius: 50px; border-radius: 5px; border: 2px solid #dddd;" />
                                            </div>
                                        </div>
                                        <div class="separator10"></div>
                                        <div class="row">
                                            <div class="col-md-5">
                                                <label class="control-label"> আবেদনকারীর নাম (ইংরেজী) <code>*</code>
                                                </label>
                                                <input name="stu_name" class="form-control" type="text" required="required" placeholder='Enter Applicant Name' />
                                            </div>

                                            <div class="col-md-4">
                                                <label class="control-label"> আবেদনকারীর অভিবাবক নাম্বার <code>*</code>
                                                </label>
                                                <input name="stu_name_op" class="form-control" type="text" required="required" placeholder='013........' />
                                            </div>
                                            <div class="col-md-3">
                                                <label class="control-label"> ছবি <code>*</code> <sup class="text-warning"> (200px/200px | Max 60KB) </sup> </label>
                                                <input type="file" name="user_avatar" id="imgInp" class="form-control" style="font-size: .75rem; background: #bad7f2;" />
                                            </div>
                                        </div>

                                        <div class="separator15"></div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label class="control-label"> পিতার নাম (ইংরেজী) <code>*</code> </label>
                                                <input name="stu_f_name" class="form-control" type="text" required="required" placeholder="Enter Father's Name" />
                                            </div>

                                            <div class="col-md-3">
                                                <label class="control-label"> পিতার এনআইডি নং <code>*</code> </label>
                                                <input name="father_nid_number" class="form-control" type="number" required="required" />
                                            </div>

                                            <div class="col-md-3">
                                                <label class="control-label"> মাতার নাম (ইংরেজী) <code>*</code> </label>
                                                <input name="stu_m_name" class="form-control" type="text" required="required" placeholder="Enter Mother's Name" />
                                            </div>

                                            <div class="col-md-3">
                                                <label class="control-label"> মাতার এনআইডি নং <code>*</code> </label>
                                                <input name="mother_nid_number" class="form-control" type="number" required="required" />
                                            </div>
                                        </div>

                                        <div class="separator15"></div>
                                        <div class="row">
                                            <div class="col-md-3 position-relative">
                                                <label class="control-label"> জন্ম তারিখ <code>*</code> </label>
                                                <input name="stu_dob" class="datepicker form-control" type="text" required="required" placeholder='dd-mm-yyyy' />
                                            </div>

                                            <div class="col-md-3">
                                                <label class="control-label"> জন্ম নিবন্ধন নং <code>*</code> </label>
                                                <input name="stu_birth_certificate" class="form-control" type="number" required="required" />
                                            </div>

                                            <div class="col-md-3 col-6">
                                                <label class="control-label"> জাতীয়তা <code>*</code> </label>
                                                <select name="stu_nationality" class="form-control" required>
                                                    <option value="" selected="selected">Select one</option>
                                                    <option value="BANGLADESHI">BANGLADESHI</option>
                                                    <option value="OTHER">OTHER</option>
                                                </select>
                                            </div>

                                            <div class="col-md-3 col-6">
                                                <label class="control-label"> রক্তের গ্রুপ </label>
                                                <select name="stu_blood_group" class="form-control">
                                                    <option value="none" selected="selected">Select One</option>
                                                    <option value="A+ve">A+ve</option>
                                                    <option value="A-ve">A-ve</option>
                                                    <option value="B+ve">B+ve</option>
                                                    <option value="B-ve">B-ve</option>
                                                    <option value="O+ve">O+ve</option>
                                                    <option value="O-ve">O-ve</option>
                                                    <option value="AB+ve">AB+ve</option>
                                                    <option value="AB-ve">AB-ve</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="separator15"></div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label class="control-label"> ই-মেইল </label>
                                                <input name="stu_email" class="form-control" type="email" placeholder='' />
                                            </div>

                                            <div class="col-md-3 col-6">
                                                <label class="control-label"> লিঙ্গ <code>*</code> </label>
                                                <select name="stu_gender" required class="form-control">
                                                    <option value="none" selected="selected">Select One</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3 col-6">
                                                <label class="control-label"> ধর্ম <code>*</code> </label>
                                                <select name="stu_religion" required class="form-control">
                                                    <option value="none" selected="selected">Select One</option>
                                                    <option value="Islam">Islam</option>
                                                    <option value="Hindu">Hindu</option>
                                                    <option value="Bouddo">Bouddo</option>
                                                    <option value="Cristian">Cristian</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label class="control-label"> বৈবাহিক অবস্থা <code>*</code> </label>
                                                <select name="stu_marital_status" required class="form-control">
                                                    <option value="none" selected="selected">Select One</option>
                                                    <option value="Single">Single</option>
                                                    <option value="Married">Married</option>
                                                    <option value="Widowed">Widowed</option>
                                                    <option value="Divorced">Divorced</option>
                                                    <option value="Separated">Separated </option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="separator15"></div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="card">
                                                    <div class="card-header bg-light-warning">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <label class="control-label-lg theme-tag mb-0">
                                                                    <strong> বর্তমান ঠিকানা (ইংরেজী) </strong>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <label class="control-label"> গ্রাম <code>*</code>
                                                                </label>
                                                                <input name="stu_present_address1" id="pre_ads_name" class="form-control" type="text" required="required" />
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="control-label"> ডাকঘর <code>*</code>
                                                                </label>
                                                                <input name="stu_present_address2" id="pre_ads_post" class="form-control" type="text" required="required" />
                                                            </div>
                                                            <div class="col-12">
                                                                <div class="separator15"></div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <label class="control-label"> উপজেলা <code>*</code>
                                                                </label>
                                                                <input name="stu_present_address3" list="upazilas" id="pre_ads_upz" class="form-control" type="text" required="required" />
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="control-label"> জেলা <code>*</code>
                                                                </label>
                                                                <input name="stu_present_address4" list="districts" id="pre_ads_dist" class="form-control" type="text" required="required" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="card">
                                                    <div class="card-header bg-light-warning">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <label class="control-label-lg theme-tag mb-0">
                                                                            <strong> স্থায়ী ঠিকানা (ইংরেজী) </strong>
                                                                        </label>
                                                                    </div>
                                                                    <div class="col-md-6 text-left text-md-right">
                                                                        <div class="checkbox-wrapper-42">
                                                                            <input id="filltoo" type="checkbox" value="" name="filltoo" onclick="filladd()" />
                                                                            <label class="cbx m-0" for="filltoo" style="margin-top: -2px !important"></label>
                                                                            <label class="lbl mb-0" for="filltoo">Same
                                                                                as Present Info</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-body position-relative">
                                                        <div id="ovly"></div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <label class="control-label"> গ্রাম <code>*</code>
                                                                </label>
                                                                <input name="stu_permanent_address1" id="per_ads_name" class="form-control" type="text" required="required" />
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="control-label"> ডাকঘর <code>*</code>
                                                                </label>
                                                                <input name="stu_permanent_address2" id="per_ads_post" class="form-control" type="text" required="required" />
                                                            </div>
                                                            <div class="col-12">
                                                                <div class="separator15"></div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <label class="control-label"> উপজেলা <code>*</code>
                                                                </label>
                                                                <input name="stu_permanent_address3" list="upazilas" id="per_ads_upz" class="form-control" type="text" required="required" />
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="control-label"> জেলা <code>*</code>
                                                                </label>
                                                                <input name="stu_permanent_address4" list="districts" id="per_ads_dist" class="form-control" type="text" required="required" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card bg-transparent border-0">
                            <div class="card-body px-0">
                                <p>
                                    Agreement of the Guardian - <br>
                                    <input type="checkbox" name="agree" id="permission" required>
                                    <label for="permission">I do here by certify that , to the best of my knowledge, all
                                        the information provided in this form is correct and i have not withheld any
                                        important information.</label>
                                </p>
                            </div>
                        </div>
                        <div class="card bg-transparent border-0">
                            <div class="card-body px-0">

                                <div class="span7 text-right">
                                    <button type="reset" class="btn btn-secondary btn-lg" >
                                    রিসেট </button>
                                    <button type="submit" name="add" class="btn custom-btn btn-lg" >
                                    আবেদনপত্র জমাদিন </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>

    <script>
        function getFile() {
            document.getElementById("upfile").click();
        }

        function sub(obj) {
            var file = obj.value;
            var fileName = file.split("\\");
            document.getElementById("yourBtn").innerHTML = fileName[fileName.length - 1];
            document.myForm.submit();
            event.preventDefault();
        }
    </script>

    <datalist id="districts">
        <option value="Bagerhat"></option>
        <option value="Bandarban"></option>
        <option value="Barguna"></option>
        <option value="Barisal"></option>
        <option value="Bhola"></option>
        <option value="Bogra"></option>
        <option value="Brahmanbaria"></option>
        <option value="Chandpur"></option>
        <option value="Chittagong"></option>
        <option value="Chuadanga"></option>
        <option value="Comilla"></option>
        <option value="Cox'sBazar"></option>
        <option value="Dhaka"></option>
    </datalist>

    <datalist id="upazilas">
        <option>Debidwar</option>
        <option>Barura</option>
        <option>Brahmanpara</option>
        <option>Chandina</option>
        <option>Chauddagram</option>
        <option>Daudkandi</option>
        <option>Homna</option>
        <option>Laksam</option>
        <option>Muradnagar</option>
        <option>Nangalkot</option>
        <option>Comilla Sadar</option>
        <option>Meghna</option>
        <option>Monohargonj</option>
        <option>Sadarsouth</option>
        <option>Titas</option>
        <option>Burichang</option>
        <option>Lalmai</option>
        <option>Chhagalnaiya</option>
        <option>Feni Sadar</option>
        <option>Sonagazi</option>
        <option>Fulgazi</option>
        <option>Parshuram</option>
    </datalist>

    <script src="assets/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-additional-methods.js"></script>



    <script>
        $.validator.addMethod('filesize', function(value, element, param) {
            return this.optional(element) || (element.files[0].size <= param * 1000000)
        }, 'File size must be less than 60 KB');
        // }, 'File size must be less than {0} MB');

        $(function() {
            "use strict";
            $("form#selectFrom").validate({
                rules: {
                    stu_guardian_nid: {
                        required: true,
                        digits: true
                    },
                    user_avatar: {
                        required: true,
                        extension: "jpg,jpeg,png",
                        filesize: .062,
                    }
                },
                messages: {
                    agree: {
                        required: "You have to accept our terms & condition",
                    },
                },
                submitHandler: function(form) {
                    // form.submit();

                    Swal.fire({
                        title: 'Are you sure to Apply?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, Confirm',
                        reverseButtons: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    })
                }
            });
        });
    </script>

    <script>
        $(function() {
            $('input').keyup(function() {
                this.value = this.value.toLocaleUpperCase();
            });
        });
    </script>


    <script>
        imgInp.onchange = evt => {
            const [file] = imgInp.files
            if (file) {
                blah.src = URL.createObjectURL(file)
            }
        }
    </script>

    <script>
        function filladd() {
            if (filltoo.checked == true) {
                $('#ovly').addClass('card-overlay');
                var pre_address = document.getElementById("pre_ads_name").value;
                var pre_post = document.getElementById("pre_ads_post").value;
                var pre_upazila = document.getElementById("pre_ads_upz").value;
                var pre_district = document.getElementById("pre_ads_dist").value;



                var copyAds = pre_address;
                var copyPost = pre_post;
                var copyUpz = pre_upazila;
                var copyDist = pre_district;


                document.getElementById("per_ads_name").value = copyAds;
                document.getElementById("per_ads_post").value = copyPost;
                document.getElementById("per_ads_upz").value = copyUpz;
                document.getElementById("per_ads_dist").value = copyDist;
            } else if (filltoo.checked == false) {
                $('#ovly').removeClass('card-overlay');
                document.getElementById("per_ads_name").value = '';
                document.getElementById("per_ads_post").value = '';
                document.getElementById("per_ads_upz").value = '';
                document.getElementById("per_ads_dist").value = '';
            }
        }
    </script>

    <style>
        .j-alert {
            width: 100%;
            height: 50px;
            position: fixed;
            bottom: 0;
            text-align: center;
            z-index: 9;
            display: none;
        }

        .j-alert p {
            display: inline-block;
            padding: 5px 15px;
            background: #222;
            color: #fff;
            font-size: 18px;
            margin: 0;
            border-radius: 5px;
        }
    </style>

    <div class="j-alert"></div>
    <script>
        $(function() {
            // window.onkeydown = function(key){
            // 	if(key.ctrlKey == true){
            // 		key.preventDefault()
            // 		$('.j-alert p').remove();
            // 		$('.j-alert').append("<p>SHORTCUT KEYS ARE DISABLED!</p>");
            // 		$('.j-alert').fadeIn(); 
            // 		setTimeout(function() {
            // 			$(".j-alert").fadeOut();
            // 		}, 5000);

            // 	}
            // };
            $(this).bind("contextmenu", function(e) {
                e.preventDefault();
                $('.j-alert p').remove();
                $('.j-alert').append("<p>RIGHT BUTTON IS DISABLED!</p>");
                $('.j-alert').fadeIn();
                setTimeout(function() {
                    $(".j-alert").fadeOut();
                }, 5000);

            });
        });
    </script>
    <div id="footer"></div>
</body>
<script>
    $(function() {
        $('#header').load("header.html");
        $('#footer').load("footer.html");
    });
</script>





</html>