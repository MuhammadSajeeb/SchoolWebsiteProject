-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2024 at 02:56 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Id` int(11) NOT NULL,
  `stu_app_class` varchar(150) DEFAULT NULL,
  `stu_group` varchar(150) DEFAULT NULL,
  `stu_name` varchar(150) DEFAULT NULL,
  `stu_name_op` varchar(11) DEFAULT NULL,
  `imgInp` varchar(250) DEFAULT NULL,
  `stu_f_name` varchar(150) DEFAULT NULL,
  `father_nid_number` varchar(20) DEFAULT NULL,
  `stu_m_name` varchar(150) DEFAULT NULL,
  `mother_nid_number` varchar(20) DEFAULT NULL,
  `stu_dob` varchar(20) DEFAULT NULL,
  `stu_birth_certificate` varchar(25) DEFAULT NULL,
  `stu_nationality` varchar(150) DEFAULT NULL,
  `stu_blood_group` varchar(150) DEFAULT NULL,
  `stu_email` varchar(150) DEFAULT NULL,
  `stu_gender` varchar(150) DEFAULT NULL,
  `stu_religion` varchar(150) DEFAULT NULL,
  `stu_marital_status` varchar(150) DEFAULT NULL,
  `stu_present_address1` varchar(150) DEFAULT NULL,
  `stu_present_address2` varchar(150) DEFAULT NULL,
  `stu_present_address3` varchar(150) DEFAULT NULL,
  `stu_present_address4` varchar(150) DEFAULT NULL,
  `stu_permanent_address1` varchar(150) DEFAULT NULL,
  `stu_permanent_address2` varchar(150) DEFAULT NULL,
  `stu_permanent_address3` varchar(150) DEFAULT NULL,
  `stu_permanent_address4` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Id`, `stu_app_class`, `stu_group`, `stu_name`, `stu_name_op`, `imgInp`, `stu_f_name`, `father_nid_number`, `stu_m_name`, `mother_nid_number`, `stu_dob`, `stu_birth_certificate`, `stu_nationality`, `stu_blood_group`, `stu_email`, `stu_gender`, `stu_religion`, `stu_marital_status`, `stu_present_address1`, `stu_present_address2`, `stu_present_address3`, `stu_present_address4`, `stu_permanent_address1`, `stu_permanent_address2`, `stu_permanent_address3`, `stu_permanent_address4`) VALUES
(3, 'Nine', 'Humanities', 'MD SAJIB', '01321798629', 'k1.PNG', 'MD ABDUL MONNAF', '45646456', 'MST HASINA', '4646464', '05-06-1998', '646464', 'BANGLADESHI', 'B-ve', 'MHMMDSAJEEB@GMAIL.COM', 'Female', 'Islam', 'Single', 'MIRBAGH,MOGHBAZAR', 'SHANTINAGAR', 'HOMNA', 'BRAHMANBARIA', 'MIRBAGH,MOGHBAZAR', 'SHANTINAGAR', 'HOMNA', 'BRAHMANBARIA'),
(4, 'Eight', 'Business Studies', 'MD SAJIB', '01321798629', 'k2.PNG', 'MD ABDUL MONNAF', '5464655456', 'MST HASINA', '4464646', '05-06-1998', '46464', 'BANGLADESHI', 'O+ve', 'MHMMDSAJEEB@GMAIL.COM', 'Female', 'Islam', 'Single', 'MIRBAGH,MOGHBAZAR', '464', 'HOMNA', 'BRAHMANBARIA', 'MIRBAGH,MOGHBAZAR', '464', 'HOMNA', 'BRAHMANBARIA'),
(5, 'Six', 'Science', 'MD SAJIB', '01321798629', 'k3.PNG', 'MD ABDUL MONNAF', '4563464654', 'MST HASINA', '465456464', '05-06-1998', '4646464', 'BANGLADESHI', 'AB+ve', 'MHMMDSAJEEB@GMAIL.COM', 'Male', 'Cristian', 'Widowed', 'MIRBAGH,MOGHBAZAR', 'SHANTINAGAR', 'SADARSOUTH', 'CHUADANGA', 'MIRBAGH,MOGHBAZAR', 'SHANTINAGAR', 'SADARSOUTH', 'CHUADANGA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Id` (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
