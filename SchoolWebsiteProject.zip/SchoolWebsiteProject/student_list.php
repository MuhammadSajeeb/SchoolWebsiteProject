<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/images/schoolLogo.jpg">

    <title> Shere-e-bangla High School </title>

    <link rel="stylesheet" href="assets/css/goolips.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="datatable/dataTable.bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/vendors/marquee/marquee.css">
    <link rel="stylesheet" href="assets/css/protip.min.css">
    <link rel="stylesheet" href="assets/index.css">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/color/color10.css">
    <link rel="stylesheet" href="assets/css/color/color-unset.css">
    <link href="assets/vendors/lightgallery/css/lightgallery.css" rel="stylesheet">

    <script src="assets/js/jquery-3.4.1.js"></script>
    <script src="assets/vendors/marquee/marquee.js"></script>
</head>

<body>
    <div id="header"></div>


    <style>
        td,
        th {
            padding: 10px;
            text-overflow: clip;
            white-space: nowrap;
        }

        th {
            font-family: roboto;
            background: #e4e4e4;
        }
        img{
            width: 150px;
            height: 20ox;
        }
    </style>

    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>আমাদের ছাত্র-ছাত্রী</h2>
                    <ul class="bread-list">
                        <li><a href="index.html">হোম<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="student_list.html">আমাদের ছাত্র-ছাত্রী</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="courses single section">

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 col-12 search_box wow fadeInUp" data-stellar-background-ratio="0.8">
                    <div class="form-style-2 p5">
                        <div>
                            <form id="searchFrom" class="form-group" method="post" action="student_list.php">
                                <div class="row">
                                    <div class="col-sm-3 form-768 mb-3 mb-sm-0">
                                        <div class="form__group field">
                                            <select id="class" name="class" class="form__field">
                                                <option value=''>Select One </option>
                                                <option value='1'>Ten</option>
                                                <option value='2'>Nine</option>
                                                <option value='3'>Eight</option>
                                                <option value='4'>Seven</option>
                                                <option value='5'>Six</option>
                                                <option value='11'>Old Ten</option>
                                            </select>
                                            <label for="class" class="form__label">শ্রেণী * : </label>
                                        </div>
                                    </div>
                                    <div class="col-sm-3 form-768 mb-3 mb-sm-0">
                                        <div class="form__group field">
                                            <select id="group" name="group" class="form__field">
                                                <option value=''>Select One </option>
                                                <option value='1'>Humanities</option>
                                                <option value='2'>Science</option>
                                                <option value='3'>Business Studies</option>
                                            </select>
                                            <label for="group" class="form__label">গ্রুপ : </label>
                                        </div>
                                    </div>
                                    <div class="col-sm-3 form-768 mb-3 mt-3 mb-sm-0 mobilemargin-0">
                                        <button id="search" name="submitButton" class="form-control1 form-control-user submit1"><i class='fa fa-search'></i> খুঁজুন</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div id="showajaxresult" class="wow zoomIn"></div>
        </div>
        </div>

    </section>


    <section>
        <div class="row">
            <table id="myTable" class="table table-bordered table-striped">
                <thead>
                    <th>Image</th>
                    <th>ID</th>
                    <th>Class Name</th>
                    <th>Group Name</th>
                    <th>Student Name</th>
                    <th>Guardian Phone</th>
                    <th>Father Name</th>
                    <th>Mother Name</th>
                    <th>M_Village</th>
                    <th>M_POT</th>
                    <th>M_Thana</th>
                    <th>M_Dist</th>
                </thead>
                <tbody>
                    <?php
                    include_once('connection.php');
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        if (isset($_POST["submitButton"])) {

                            $sql = "SELECT imgInp,Id ,stu_app_class,stu_group,stu_name,stu_name_op,stu_f_name,stu_m_name,stu_present_address1,stu_present_address2,stu_present_address3,stu_present_address4 FROM `students`";
                            $query = $conn->query($sql);
                            while ($row = $query->fetch_assoc()) {
                                
                                // "<tr>
                                
                                //         <td><img src='. $row['imgInp']. '> </td>
                                        
                                //         <td>" . $row['Id'] . "</td>
                                //         <td>" . $row['stu_app_class'] . "</td>
                                //         <td>" . $row['stu_group'] . "</td>
                                //         <td>" . $row['stu_name'] . "</td>
                                //         <td>" . $row['stu_name_op'] . "</td>
                                //         <td>" . $row['stu_f_name'] . "</td>
                                //         <td>" . $row['stu_m_name'] . "</td>
                                //         <td>" . $row['stu_present_address1'] . "</td>
                                //         <td>" . $row['stu_present_address2'] . "</td>
                                //         <td>" . $row['stu_present_address3'] . "</td>
                                //         <td>" . $row['stu_present_address4'] . "</td>

                                //     </tr>";
                                echo '<td><img src="images/'.($row["imgInp"]) . '" height="10" /></td>';
                                echo "<td>" . $row["Id"] . "</td>";
                                echo "<td>" . $row['stu_app_class'] . "</td>";
                                echo "<td>" . $row['stu_group'] . "</td>";
                                echo "<td>" . $row['stu_name'] . "</td>";
                                echo "<td>" . $row['stu_name_op'] . "</td>";
                                echo "<td>" . $row['stu_f_name'] . "</td>";
                                echo "<td>" . $row['stu_m_name'] . "</td>";
                                echo "<td>" . $row['stu_present_address1'] . "</td>";
                                echo "<td>" . $row['stu_present_address2'] . "</td>";
                                echo "<td>" . $row['stu_present_address3'] . "</td>";
                                echo "<td>" . $row['stu_present_address4'] . "</td>";
                                echo "</tr>";
                            }
                        }
                    } else {
                        echo '<script>alert("তথ্য দেখতে খুজুন বাটন এ কিল্ক করুন")</script>';
                    }

                    ?>
                </tbody>
            </table>
        </div>
    </section>


    <div id="footer"></div>
</body>
<script>
    $(function() {
        $('#header').load("header.html");
        $('#footer').load("footer.html");
    });
</script>
<script src="jquery/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>
<script src="datatable/dataTable.bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        //inialize datatable
        $('#myTable').DataTable();

        //hide alert
        $(document).on('click', '.close', function() {
            $('.alert').hide();
        })
    });
</script>

</html>